"<?php phpinfo(); ?>" 
